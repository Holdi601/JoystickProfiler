
Brass's DCS F-18/FC3 Profile V01 For JOYPRO V83
2022 07 27

Controllers:
============
WinWing F-16EX Joystick
Virpil CM3 Throttle


G'day,

Firstly, many many thanks go to Holdi601 for the time and effort he puts into creating this absolutely ESSENTIAL program. I used to spend weeks AND months sorting out keybinds for my old X55/X56 HOTAS. JoyPro has made the whole process so simple and so quick for any controller!

For testing of joysticks HID outputs I thoroughly recommend Pointy's Joystick test program ver 0.9.2
http://www.planetpointy.co.uk/joystick-test-application/

About the profile;
------------------
NOTE: This profile was configured around the F-18 Module. Flaming Cliffs 3 aircraft were added where possible. The profile is INCOMPLETE as other modules will need to be fully configured. See the file "Controller Layout Draft 05sml.png" for an idea on the logic behind how the buttons were configured. It is assumed that you are familiar with using JoyPro V83. Use this profile and modify it as you see fit.

As always, use these files at you own risk. This profile works for me but your mileage may differ.
===================================================================================================


The "Profiles and Relations" Directory contains the profile and associated relations that were incorporated into making the profile. The layouts were broken up into the following Kneeboards;

F-16EX_Front
F-16EX_back
Virpil_CM3_Base
Virpil_CM3_Front
Virpil_CM3_Rear

When exporting to kneeboard append the proper suffix. ie. "_Front" to the Virpil_Cm3 Front layout in the Postfix field. (See "CaptureAddingPostfix.png") When all 5 kneeboards are exported appropriately you should see something like "CaptureKneeboardsExported.png" for each aircraft.

Use the export Easy Kneeboards as you see fit.


WinWing F-16EX Joystick
-----------------------
The profile relies on the basic HID output of the Joystick. Button numbers in the layout correspond to the actual buttons on the joystick. In this case the Rx/Ry analogue were configured to act as buttons. Sorry but no configuration for that is supplied here. 

Virpil CM3 Throttle
-------------------
The profile relies on the basic HID output of the Throttle. Button numbers in the layout correspond to the actual buttons on the Throttle. Additional buttons were programmed with the Virpil VPC Configuration Tool and exported as "Virpil CM3 Throttle Setup Brass 20220726a.XML". Buttons for Idle and Cutoff finger lift are programmed on the throttle. The T1-T4 buttons have a button for up and down. See the file "Virpil CM3 Throttle Setup Brass 20220726a.XML" as a setup for the Throttle.

I hope this profile works for you,

Cheers,

Brass.

 

